package su.xash.engine

class DedicatedActivity {}
