package su.xash.engine

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import su.xash.engine.databinding.ActivityMyMenuBinding

class MyMenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMyMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlay.setOnClickListener {
            val i = Intent(this, MainActivity::class.java)
            startActivity(i)
            finish()
        }
    }
}
